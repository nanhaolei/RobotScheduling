﻿#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <queue>
#include <random>
#include <cmath>
#include "Robot.cpp"
using namespace std;
vector<Workbench> workbenchs;
vector<Robot> robots;
vector<Workbench*> workbenchs_1;
vector<Workbench*> workbenchs_2;
vector<Workbench*> workbenchs_3;
vector<Workbench*> workbenchs_4;
vector<Workbench*> workbenchs_5;
vector<Workbench*> workbenchs_6;
vector<Workbench*> workbenchs_7;
vector<Workbench*> workbenchs_8;
vector<Workbench*> workbenchs_9;
int workbench_num = 0;
int workbench_num_1 = 0;
int workbench_num_2 = 0;
int workbench_num_3 = 0;
int workbench_num_4 = 0;
int workbench_num_5 = 0;
int workbench_num_6 = 0;
int workbench_num_7 = 0;
int workbench_num_8 = 0;
int workbench_num_9 = 0;
int frameId = 0;

//struct TempWorkbench {
//    int workbenchId;
//    double distance;
//    TempWorkbench(int id, double d) : workbenchId(id), distance(d) {};
//};
//struct compare {
//    bool operator() (const TempWorkbench& w1, const TempWorkbench& w2){
//        return w1.distance > w2.distance;
//    }
//};
//// 寻找目标类型工作台中 成品格有物品 且最近的四个
//vector<int> findBuyBench(const int& robotId, const vector<Workbench*>& workbenchs_n, const int& workbench_num) {
//    priority_queue<TempWorkbench, vector<TempWorkbench>, compare> closetWorkbenchs;
//    vector<int> target_benchs;
//    for (int i = 0; i < workbench_num; ++i) {
//        int workbenchId = workbenchs_n[i]->getWorkbenchId();
//        if (workbenchs_n[i]->getProductStatus() == 1) {
//            double distance = robots[robotId].calDistance(workbenchs[workbenchId]);
//            TempWorkbench workbench = TempWorkbench( workbenchId, distance );
//            if (closetWorkbenchs.size() < 4) {
//                closetWorkbenchs.push(workbench);
//            }
//            else if(distance < closetWorkbenchs.top().distance) {
//                closetWorkbenchs.pop();
//                closetWorkbenchs.push(workbench);
//            }
//        }
//    }
//    while (!closetWorkbenchs.empty()) {
//        target_benchs.emplace_back(closetWorkbenchs.top().workbenchId);
//        closetWorkbenchs.pop();
//    }
//    reverse(target_benchs.begin(), target_benchs.end());
//    return target_benchs;
//}
// 寻找不与其他机器人的目标冲突的一个工作台
//int findBenchWithoutConflict(vector<int>& target_benchs) {
//    int size = target_benchs.size();
//    int target_bench = target_benchs[0];
//    for (int index = 0; index < size; ++index) {
//        for (auto& robot : robots) {
//            if (robot.getTargetBenchId() == target_bench) {
//                target_bench = target_benchs[++index];
//                break;
//            }
//        }
//    }
//    return target_bench;
//}

// 十进制转二进制
void decimalToBinary(int n, vector<int>& binary) {
    int i = 0;
    while (n > 0) {
        //binary.insert(binary.begin(), n % 2); //高位在前
        //binary.push_back(n % 2); // 低位在前
        binary[i] = n % 2;
        n /= 2;
        ++i;
    }
}

// 检查目标工作台中该材料是否空余
bool checkMaterialStatus(const int& goodsType, const int& workbenchId, vector<int>& binary) {
    int materialStatus = workbenchs[workbenchId].getMaterialStatus();
    decimalToBinary(materialStatus, binary);
    if (binary[goodsType] == 0) {
        return true;
    }
    else {
        return false;
    }
}

// 当前目标冲突检测
bool checkConflict(const int& robotId, const int& target_bench) {
    bool isSelected = false;
    // 89不做冲突检测
    if (workbenchs[target_bench].getType() == 8 || workbenchs[target_bench].getType() == 9) {
        return isSelected;
    }
    for (auto& robot : robots) {
        // 目标相同且携带物品相同
        if (robot.getRobotId() != robotId &&
            robot.getTargetBenchId() == target_bench &&
            robot.getGoodsType() == robots[robotId].getGoodsType())
        {
            isSelected = true;
            break;
        }
    }
    return isSelected;
}

// 计算到目标工作台的时间是否在允许等待范围内
double calAllowWaitTime(double rest_time,double move_time,int bench_type) {
    double allow_wait_frame;
    // 生产时间大于移动时间
    if (rest_time > move_time)
    {
        // 123工作台允许等待10帧
        if (bench_type == 1 || bench_type == 2 || bench_type == 3) {
            allow_wait_frame = 10;
        }
        // 7工作台不等
        else if (bench_type == 7) {
            allow_wait_frame = 0;
        }
        // 456工作台允许等待40帧
        else {
            allow_wait_frame = 10;
        }

        //allow_wait_frame = 0;

        // 在允许等待范围内
        if (rest_time - move_time <= allow_wait_frame / FPS) {
            return rest_time;
        }
        // 不在允许等待范围内
        else {
            return 99999;
        }
    }
    // 生产时间小于移动时间
    else {
        return move_time;
    }
}

// 计算卖出优先级
double calSellPriority(const double& distance, const int& workbenchId, const int& goodsType) {
    vector<int> binary(8, 0);
    bool material_status = checkMaterialStatus(goodsType, workbenchId, binary);

    // 目标材料格不空余而且不在生产
    if (!material_status && workbenchs[workbenchId].getRestFrame() <= 0) {
        return 99999;
    }

    int bench_type = workbenchs[workbenchId].getType();
    double speed = MAX_FORWARD_SPEED;
    double offset = 1.2;
    double move_time = distance / speed * offset;
    double rest_time = workbenchs[workbenchId].getRestFrame() / static_cast<double>(FPS);

    // 89工作台始终为运动时间
    if (bench_type == 8 || bench_type == 9) {
        return move_time;
    }
    // 计算几个材料格不空余
    int full_count = 0;
    for (int i = 0; i < 8; ++i) {
        if (binary[i] == 1) ++full_count;
    }
    // 7工作台材料格空余 且 只缺一个 且 不在生产 
    if ((bench_type == 7 && material_status && full_count == 2) && workbenchs[workbenchId].getRestFrame() < 0) {
        //cerr << "test0" << endl;
        return move_time / 4;
    }
    // 7不在生产时 且 当前材料没有被预订 提高买入456的优先级
    /*for (auto bench7 : workbenchs_7) {
        if (bench7->getRestFrame() < 0 && !bench7->getReservedGoods(bench_type) &&
            (bench_type == 4 || bench_type == 5 || bench_type == 6) && workbenchs[workbenchId].getProductStatus() == 1)
        {
            return move_time / 3;
        }
    }*/
    // 456工作台材料格空余 且 只缺一个  (有7工作台）
    if ((bench_type == 4 || bench_type == 5 || bench_type == 6) && full_count == 1 && material_status && workbench_num_7 > 0) {
        //cerr << "test11" << endl;
        return move_time / 2;
    }
    // 456工作台材料格空余 且 只缺一个 （无7工作台）
    if ((bench_type == 4 || bench_type == 5 || bench_type == 6) && full_count == 1 && material_status && workbench_num_7 == 0) {
        //cerr << "test2" << endl;
        return move_time / 1.2;
    }
    // 目标材料格空余 缺一个以上
    if (material_status) {
        //cerr << "test3" << endl;
        return move_time;
    }
    // 正在生产 且 所有材料格都不空余 且 产品格没物品 
    if (full_count == 2 && workbenchs[workbenchId].getProductStatus() == 0 && (bench_type == 4 || bench_type == 5 || bench_type == 6)) {
        //cerr << "test4" << endl;
        //return rest_time;
        return calAllowWaitTime(rest_time, move_time, bench_type);
    }
    if (full_count == 3 && workbenchs[workbenchId].getProductStatus() == 0 && bench_type == 7) {
        //cerr << "test5" << endl;
        //return rest_time;
        return calAllowWaitTime(rest_time, move_time, bench_type);
    }
    return 99999;
}

// 判断能收购该物品类型的工作台
vector<Workbench*> findSellBenchs(const int& goods_type) {
    //int goods_type = robots[robotId].getGoodsType();
    vector<Workbench*> workbenchs_n;
    switch (goods_type)
    {
    case 1:
        if (workbench_num_4 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_4.begin(), workbenchs_4.end());
        if (workbench_num_5 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_5.begin(), workbenchs_5.end());
        if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        break;
    case 2:
        if (workbench_num_4 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_4.begin(), workbenchs_4.end());
        if (workbench_num_6 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_6.begin(), workbenchs_6.end());
        if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        break;
    case 3:
        if (workbench_num_5 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_5.begin(), workbenchs_5.end());
        if (workbench_num_6 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_6.begin(), workbenchs_6.end());
        if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        break;
    case 4:
    case 5:
    case 6:
        if (workbench_num_7 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_7.begin(), workbenchs_7.end());
        if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        break;
    case 7:
        if (workbench_num_8 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_8.begin(), workbenchs_8.end());
        if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        break;
    default:
        std::cerr << "error:findSellBenchs" << endl;
        break;
    }
    return workbenchs_n;
}

// 寻找优先级最高的卖出工作台
int findSellBench(const int& robotId) {
    // 计算能收购该物品类型的工作台
    int goods_type = robots[robotId].getGoodsType();
    vector<Workbench*> workbenchs_n = findSellBenchs(goods_type);
    int size = workbenchs_n.size();

    // 计算优先级最高的工作台
    //int target_bench = -1;
    int target_bench = workbenchs_n[0]->getWorkbenchId();
    double min_time = 99999;
    for (int i = 0; i < size; ++i) {
        int workbench_id = workbenchs_n[i]->getWorkbenchId();
        double distance = robots[robotId].calDistance(*workbenchs_n[i]);
        double time = calSellPriority(distance, workbench_id, robots[robotId].getGoodsType());
        // 若目标为89不判断目标冲突
        if (workbenchs[workbench_id].getType() == 8 || workbenchs[workbench_id].getType() == 9) {
            if (time < min_time) {
                min_time = time;
                target_bench = workbench_id;
            }
        }
        // 判断冲突
        else if (!checkConflict(robotId, workbench_id)) {
            if (time < min_time) {
                min_time = time;
                target_bench = workbench_id;
            }
        }

    }
    if (target_bench == -1) {
        cerr << "error:findSellBench" << endl;
    }
    return target_bench;
}

// 计算买入优先级
double calBuyPriority(const int& robotId, const int& workbenchId) {
    // 不在生产 并且 没有产品
    if (workbenchs[workbenchId].getRestFrame() < 0 && workbenchs[workbenchId].getProductStatus() == 0) {
        return 99999;
    }
    
    double distance = robots[robotId].calDistance(workbenchs[workbenchId]);
    double speed = MAX_FORWARD_SPEED;
    double offset = 1.1;
    double move_time = distance / speed * offset;
    double rest_time = workbenchs[workbenchId].getRestFrame() / static_cast<double>(FPS);
    int bench_type = workbenchs[workbenchId].getType();

    if (bench_type == 7 && workbenchs[workbenchId].getRestFrame() != 0) {
        return 99999;
    }

    if (workbenchs[workbenchId].getProductStatus() == 1) {
        // 产品格阻塞
        /*if ((bench_type == 4 || bench_type == 5 || bench_type == 6 || bench_type == 7) && rest_time == 0) {
            return move_time / 10;
        }*/
        // 最后一段时间提高4567的优先级
        /*if ((bench_type == 4 || bench_type == 5 || bench_type == 6 || bench_type == 7) && frameId > 8000) {
            return move_time / 1;
        }*/
        // 7不在生产 且 7的该材料格没有被预订 
        for (auto bench7 : workbenchs_7) {
            if (bench7->getRestFrame() < 0 && !bench7->getReservedGoods(bench_type) &&
                (bench_type == 4 || bench_type == 5 || bench_type == 6) && workbenchs[workbenchId].getProductStatus() == 1)
            {
                return move_time / 3;
            }
        }
        // 已经有产品
        if (workbenchs[workbenchId].getProductStatus() == 1 || rest_time == 0) {
            return move_time;
        }
    }
    // 正在生产
    else if (rest_time > 0) {
        return calAllowWaitTime(rest_time, move_time, bench_type);
    }
    cerr << "framid:" << frameId << endl;
    cerr << "err:calBuyPriority" << endl;
    return 99999;
}

// 寻找优先级最高的买入工作台
int findBuyBench(const int& robotId, const vector<Workbench*>& workbenchs_n, const int& workbench_num) {
    int target_bench = -1;
    double min_time = 99999;
    for (int i = 0; i < workbench_num; ++i) {
        int workbench_id = workbenchs_n[i]->getWorkbenchId();
        double time = calBuyPriority(robotId, workbench_id);
        // 如果为123工作台 不判断目标冲突
        if (workbenchs_n[i]->getType() == 1 || workbenchs_n[i]->getType() == 2 || workbenchs_n[i]->getType() == 3) {
            if (time < min_time) {
                min_time = time;
                target_bench = workbench_id;
            }
        }
        // 否则先判断目标冲突
        else if (!checkConflict(robotId, workbench_id)) {
            if (time < min_time) {
                min_time = time;
                target_bench = workbench_id;
            }
        }
    }
    return target_bench;
}
int findBuyBench(const int& robotId, const vector<Workbench>& workbenchs_n, const int& workbench_num) {
    int target_bench = -1;
    double min_time = 99999;
    for (int i = 0; i < workbench_num; ++i) {
        int workbench_id = workbenchs_n[i].getWorkbenchId();
        double time = calBuyPriority(robotId, workbench_id);
        // 如果为123工作台 不判断目标冲突
        if (workbenchs_n[i].getType() == 1 || workbenchs_n[i].getType() == 2 || workbenchs_n[i].getType() == 3) {
            if (time < min_time) {
                min_time = time;
                target_bench = workbench_id;
            }
        }
        // 否则先判断目标冲突
        else if (!checkConflict(robotId, workbench_id)) {
            if (time < min_time) {
                min_time = time;
                target_bench = workbench_id;
            }
        }
    }
    return target_bench;
}

// 给定工作台 找缺失的材料
int findLostMaterial(const int& workbenchId) {
    int bench_type = workbenchs[workbenchId].getType();
    int material = workbenchs[workbenchId].getMaterialStatus();
    int goods_type = 1;
    int ran[2]{ -1, 1 };
    random_device rd;  //如果可用的话，从一个随机数发生器上获得一个真正的随机数
    mt19937 gen(rd()); //gen是一个使用rd()作种子初始化的标准梅森旋转算法的随机数发生器
    uniform_int_distribution<> distrib1(0, 1);
    uniform_int_distribution<> distrib2(0, 2);
    switch (bench_type)
    {
    case 4:
        // 有1缺2
        if (material == 2) {
            goods_type = 2;
        }
        // 有2缺1
        else if (material == 4) {
            goods_type = 1;
        }
        // 都缺
        else {
            goods_type = 2;
        }
        break;
    case 5:
        // 有1缺3
        if (material == 2) {
            goods_type = 3;
        }
        // 有3缺1
        else if (material == 8) {
            goods_type = 1;
        }
        // 都缺
        else {
            goods_type = 1;
        }
        break;
    case 6:
        // 有2缺3
        if (material == 4) {
            goods_type = 3;
        }
        // 有3缺2
        else if (material == 8) {
            goods_type = 2;
        }
        // 都缺
        else {
            goods_type = 3;
        }
        break;
    case 7:
        switch (material)
        {
            // 有45缺6
        case 48:
            goods_type = 6;
            break;
            // 有46缺5
        case 80:
            goods_type = 5;
            break;
            // 有56缺4
        case 96:
            goods_type = 4;
            break;
            // 有4缺56
        case 16:
            goods_type = 5 + distrib1(gen); // 随机56
            break;
            // 有5缺46
        case 32:
            goods_type = 5 + ran[rand() % 2]; // 随机46
            break;
            // 有6缺45
        case 64:
            goods_type = 4 + distrib1(gen); // 随机45
            break;
            // 都缺
        default:
            goods_type = 4 + distrib2(gen); // 随机456
            break;
        }
        break;
    default:
        break;
    }

    return goods_type;
}

// 给定目标工作台类型 计算买到它缺失的材料并带过去的时间最短的路径 （只针对456工作台）
int findFastestBench(const int& robotId, const vector<Workbench*>& workbenchs_n) {
    double min_time = 99999;
    int target_bench = -1;
    vector<Workbench*>* buy_benchs = nullptr;
    int sell_benchId = -1;
    // 遍历每个n号工作台 
    for (auto sell_bench : workbenchs_n) {
        //sell_benchId = sell_bench->getWorkbenchId();
        // 判断他缺哪个材料
        int lost_material = findLostMaterial(sell_bench->getWorkbenchId());
        switch (lost_material)
        {
        case 1:
            buy_benchs = &workbenchs_1;
            break;
        case 2:
            buy_benchs = &workbenchs_2;
            break;
        case 3:
            buy_benchs = &workbenchs_3;
            break;
        default:
            cerr << "err:findBench" << endl;
            break;
        }
        // 遍历所有能买到该材料的工作台
        for (auto buy_bench : *buy_benchs) {
            int buy_benchId = buy_bench->getWorkbenchId();
            double buy_time = calBuyPriority(robotId, buy_benchId);
            double offset = 1.1;
            double sell_time = buy_bench->calDistance(workbenchs[sell_bench->getWorkbenchId()]) / MAX_FORWARD_SPEED * offset;
            // 计算总耗时最短的
            if (buy_time + sell_time < min_time) {
                min_time = buy_time + sell_time;
                target_bench = buy_benchId;
                sell_benchId = sell_bench->getWorkbenchId();
                //robots[robotId].setSellBenchId(sell_benchId);
            }
        }
    }
    robots[robotId].setSellBenchId(sell_benchId);
    workbenchs[sell_benchId].setReservedGoods(workbenchs[target_bench].getType(), true);
    if (target_bench == -1) {
        cerr << "err:findBench:target_bench==-1" << endl;
    }
    return target_bench;
}

// 给定目标工作台类型 找最近的一个
int findClosetBench(const int& robotId, const vector<Workbench*>& workbenchs_n, const int& workbench_num) {
    int target_bench = -1;
    double min_distance = 99999;
    for (int i = 0; i < workbench_num; ++i) {
        int workbench_id = workbenchs_n[i]->getWorkbenchId();
        double distance = robots[robotId].calDistance(workbenchs[workbench_id]);
        if (distance < min_distance) {
            min_distance = distance;
            target_bench = workbench_id;
        }
    }
    return target_bench;
}

// 给定所需材料类型 找一个工作台去买
int findMaterial(const int& robotId, int goods_type, const int& sell_bench) {
    int target_bench = -1;
    int workbenchId;
    switch (goods_type)
    {
    case 1:
        target_bench = findBuyBench(robotId, workbenchs_1, workbench_num_1);
        if (target_bench == -1) {
            target_bench = workbenchs_1[0]->getWorkbenchId();
            cerr << "err:findMaterial" << endl;
        }
        break;
    case 2:
        target_bench = findBuyBench(robotId, workbenchs_2, workbench_num_2);
        if (target_bench == -1) {
            target_bench = workbenchs_2[0]->getWorkbenchId();
            cerr << "err:findMaterial" << endl;
        }
        break;
    case 3:
        target_bench = findBuyBench(robotId, workbenchs_3, workbench_num_3);
        if (target_bench == -1) {
            target_bench = workbenchs_3[0]->getWorkbenchId();
            cerr << "err:findMaterial" << endl;
        }
        break;
    case 4:
        target_bench = findBuyBench(robotId, workbenchs_4, workbench_num_4);
        // 找不到有这个材料的工作台
        if (target_bench == -1)
        {
            /*// 判断最近的一个4号工作台缺哪个材料 去找这个材料带回来
            workbenchId = findClosetBench(robotId, workbenchs_4, workbench_num_4);
            robots[robotId].setSellBenchId(workbenchs[workbenchId]);
            goods_type = findLostMaterial(workbenchId);
            target_bench = findMaterial(robotId, goods_type);*/

            // 找买入卖出总时间最短的一条路径带回来
            target_bench = findFastestBench(robotId, workbenchs_4);
        }
        else {
            robots[robotId].setSellBenchId(sell_bench);
            workbenchs[sell_bench].setReservedGoods(workbenchs[target_bench].getType(), true);
        }
        break;
    case 5:
        target_bench = findBuyBench(robotId, workbenchs_5, workbench_num_5);
        if (target_bench == -1)
        {
            /*// 判断最近的一个5号工作台缺哪个材料 去找这个材料带回来
            workbenchId = findClosetBench(robotId, workbenchs_5, workbench_num_5);
            robots[robotId].setSellBenchId(workbenchs[workbenchId]);
            goods_type = findLostMaterial(workbenchId);
            target_bench = findMaterial(robotId, goods_type);*/

            // 找买入卖出总时间最短的一条路径带回来
            target_bench = findFastestBench(robotId, workbenchs_5);
        }
        else {
            robots[robotId].setSellBenchId(sell_bench);
            workbenchs[sell_bench].setReservedGoods(workbenchs[target_bench].getType(), true);
        }
        break;
    case 6:
        target_bench = findBuyBench(robotId, workbenchs_6, workbench_num_6);
        if (target_bench == -1)
        {
            /*// 判断最近的一个6号工作台缺哪个材料 去找这个材料带回来
            workbenchId = findClosetBench(robotId, workbenchs_6, workbench_num_6);
            robots[robotId].setSellBenchId(workbenchs[workbenchId]);
            goods_type = findLostMaterial(workbenchId);
            target_bench = findMaterial(robotId, goods_type);*/

            // 找买入卖出总时间最短的一条路径带回来
            target_bench = findFastestBench(robotId, workbenchs_6);
        }
        else {
            robots[robotId].setSellBenchId(sell_bench);
            workbenchs[sell_bench].setReservedGoods(workbenchs[target_bench].getType(), true);
        }
        break;
    case 7:
        target_bench = findBuyBench(robotId, workbenchs_7, workbench_num_7);
        if (target_bench == -1)
        {
            // 判断最近的一个7号工作台缺哪个材料 去买这个材料
            workbenchId = findClosetBench(robotId, workbenchs_7, workbench_num_7);
            /*if (workbench_num_7 > 1) {
                robots[robotId].setSellBenchId(workbenchs[workbenchId]);
            }*/

            goods_type = findLostMaterial(workbenchId);
            target_bench = findMaterial(robotId, goods_type, workbenchId);
        }
        break;
    default:
        break;
    }

    return target_bench;
}

// 计算物品利润
double calProfit(int goods_type) {
    switch (goods_type)
    {
    case 1:
        return 3000;
        break;
    case 2:
        return 3200;
        break;
    case 3:
        return 3400;
        break;
    case 4:
        return 7100;
        break;
    case 5:
        return 7800;
        break;
    case 6:
        return 8300;
        break;
    case 7:
        return 29000;
        break;
    default:
        break;
    }
    cerr << "err:calProfit" << endl;
    return -1;
}

// 单位利润最高优先
int unit_profit_first(const int& robotId) {
    double max_unit_profit = 0;
    int buy_bench_id = -1;
    int sell_bench_id = -1;
    for (auto& buy_bench : workbenchs) {
        // 目标冲突检测
        if (checkConflict(robotId, buy_bench.getWorkbenchId())) {
            continue;
        }
        // 计算买入时间
        double buy_time = calBuyPriority(robotId, buy_bench.getWorkbenchId());
        if (buy_time > 99998) {
            continue; // 无法去该工作台买入
        }

        // 计算卖出时间
        int goods_type = buy_bench.getType();
        vector<Workbench*> sell_benchs = findSellBenchs(goods_type);
        for (auto sell_bench : sell_benchs) {
            // 目标冲突检测
            if (!sell_bench->getReservedGoods(goods_type) /*&& !checkConflict(robotId, sell_bench->getWorkbenchId())*/) {
                double distance = buy_bench.calDistance(*sell_bench);
                double sell_time = calSellPriority(distance, sell_bench->getWorkbenchId(), goods_type);
                double total_time = buy_time + sell_time;
                double unit_profit = calProfit(goods_type) / total_time;
                if (unit_profit > max_unit_profit) {
                    max_unit_profit = unit_profit;
                    buy_bench_id = buy_bench.getWorkbenchId();
                    sell_bench_id = sell_bench->getWorkbenchId();
                }
            }
        }
    }
    if (buy_bench_id == -1 || sell_bench_id == -1) {
        cerr << "frameid:" << frameId << endl;
        cerr << "err:unit_profit_first" << endl;
        cerr << "robotId:" << robotId << endl;
        cerr << "max_unit_profit:" << max_unit_profit << endl;
        cerr << "target_bench:" << buy_bench_id << endl;
        cerr << "sell_benchid:" << sell_bench_id << endl;
    }

    robots[robotId].setSellBenchId(sell_bench_id);
    
    // 卖出目标不为8，9 设置预订标记
    /*if(workbenchs[sell_bench_id].getType() != 8 && workbenchs[sell_bench_id].getType() != 9){
        workbenchs[sell_bench_id].setReservedGoods(workbenchs[buy_bench_id].getType(), true);
    }*/
    workbenchs[sell_bench_id].setReservedGoods(workbenchs[buy_bench_id].getType(), true);
    
    // 若更换目标 清除预订标记
    /*int old_sellbenchid = robots[robotId].getSellBenchId();
    if (old_sellbenchid != sell_benchid) {
        workbenchs[sell_benchid].setReservedGoods(workbenchs[robots[robotId].getTargetBenchId()].getType(), false);
    }
    robots[robotId].setSellBenchId(sell_benchid);
    workbenchs[sell_benchid].setReservedGoods(workbenchs[target_bench].getType(), true);*/
    return buy_bench_id;
}

// 高级物品优先
int senior_first(const int& robotId) {
    int target_bench = -1;
    int size = 0;
    // 优先买7    
    target_bench = findBuyBench(robotId, workbenchs_7, workbench_num_7);
    if (target_bench != -1) {
        return target_bench;
    }

    // 其次买456
    vector<Workbench*> workbenchs_456;
    workbenchs_456.insert(workbenchs_456.end(), workbenchs_4.begin(), workbenchs_4.end());
    workbenchs_456.insert(workbenchs_456.end(), workbenchs_5.begin(), workbenchs_5.end());
    workbenchs_456.insert(workbenchs_456.end(), workbenchs_6.begin(), workbenchs_6.end());
    size = workbenchs_456.size();
    target_bench = findBuyBench(robotId, workbenchs_456, size);
    if (target_bench != -1) {
        return target_bench;
    }

    // 最后买123
    vector<Workbench*> workbenchs_123;
    workbenchs_123.insert(workbenchs_123.end(), workbenchs_1.begin(), workbenchs_1.end());
    workbenchs_123.insert(workbenchs_123.end(), workbenchs_2.begin(), workbenchs_2.end());
    workbenchs_123.insert(workbenchs_123.end(), workbenchs_3.begin(), workbenchs_3.end());
    size = workbenchs_123.size();
    target_bench = findBuyBench(robotId, workbenchs_123, size);
    if (target_bench != -1) {
        return target_bench;
    }
    cerr << "err:senior_first" << endl;
    return target_bench;
}

// 最近优先
int closest_first(const int& robotId) {
    int target_bench = -1;
    target_bench = findBuyBench(robotId, workbenchs, workbench_num);
    if (target_bench == -1) {
        cerr << "err:closest_first" << endl;
    }
    return target_bench;
}

// 判断是否位于456工作台上 且该工作台只缺一个材料 返回该材料
int judge_1(const int& robotId) {
    int workbenchId = robots[robotId].getWorkbenchId();
    if (workbenchId == -1) {
        return 0;
    }
    int type = workbenchs[workbenchId].getType();
    int material = workbenchs[workbenchId].getMaterialStatus();
    int goods_type = 0;
    if (material != 0 && (type == 4 || type == 5 || type == 6)) {
        goods_type = findLostMaterial(workbenchId);
    }
    return goods_type;
}

// 判断是否 7号工作台没有目标是它 且 只缺一个材料 
bool judge_2(int& sell_bench, int& goods_type) {
    for (auto workbench : workbenchs_7) {
        // 判断是否只缺一个材料 若是获取该材料
        int material = workbench->getMaterialStatus();
        goods_type = 0;
        switch (material)
        {
            // 有45缺6
        case 48:
            goods_type = 6;
            break;
            // 有46缺5
        case 80:
            goods_type = 5;
            break;
            // 有56缺4
        case 96:
            goods_type = 4;
            break;
        default:
            goods_type = 0;
            break;
        }
        if (!workbench->getReservedGoods(goods_type) && goods_type != 0 ) {
            sell_bench = workbench->getWorkbenchId();
            return true;
        }
    }
    return false;
}

// 判断是否有7号工作台生产完毕 且 没有机器人目标是他
int judge_3() {
    for (auto workbench : workbenchs_7) {
        bool is_selected = false;
        // 生产完毕
        if (workbench->getProductStatus()) {
            for (auto& robot : robots) {
                if (robot.getTargetBenchId() == workbench->getWorkbenchId()) {
                    is_selected = true;
                    break;
                }
            }
            // 没有被作为目标
            if (!is_selected) {
                return workbench->getWorkbenchId();
            }
        }
    }
    return -1;
}

// 判断目标台是否为4567 并计算剩余时间够不够拿到4567并卖掉
bool judge_4(const int& robotId, const int& buy_bench) {
    int goods = workbenchs[buy_bench].getType();
    if (goods == 7 || goods == 5 || goods == 6 || goods == 4) {
        // 计算到目标工作台的时间
        double distance = robots[robotId].calDistance(workbenchs[buy_bench]);
        double offset = 1.2;
        double buy_time = distance / MAX_FORWARD_SPEED * offset;
        // 计算卖掉的最短时间
        vector<Workbench*> workbenchs_n;
        //int sell_benchId;
        double min_distance = 99999;
        if (goods == 7)
        {
            if (workbench_num_8 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_8.begin(), workbenchs_8.end());
            if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        }
        else {
            if (workbench_num_7 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_7.begin(), workbenchs_7.end());
            if (workbench_num_9 > 0) workbenchs_n.insert(workbenchs_n.end(), workbenchs_9.begin(), workbenchs_9.end());
        }
        for (auto sell_bench : workbenchs_n) {
            // 判断有空位
            vector<int> binary(8, 0);
            if (checkMaterialStatus(goods, buy_bench, binary)) {
                double sell_distance = workbenchs[buy_bench].calDistance(*sell_bench);
                if (sell_distance < min_distance) {
                    min_distance = sell_distance;
                    //sell_benchId = sell_bench->getWorkbenchId();
                }
            }
        }
        double sell_time = min_distance / MAX_FORWARD_SPEED * offset;
        int rest_frame = 9000 - frameId;
        // 需要的时间大于剩余时间
        if (buy_time + sell_time > rest_frame / static_cast<double>(FPS)) {
            return true;
        }
        else {
            return false;
        }
    }
    return false;
}

bool judeg_5(const int& robotId, int& bench_7) {
    bench_7 = robots[robotId].getWorkbenchId();
    if (bench_7 != -1 && workbenchs[bench_7].getType() == 7 && workbenchs[bench_7].getProductStatus() == 1 && !checkConflict(robotId,bench_7)) {
        return true;
    }
    return false;
}

// 碰撞检测
//void checkCollision(const int& robotId) {
//    double check_distance = 3 * RADUIS_FULL;
//    double offset_angle = PI / 3;
//    for (auto& robot : robots) {
//        if (robot.getRobotId() != robotId && robot.calDistance(robots[robotId]) < check_distance) {
//            double dir = robots[robotId].getDirection();
//            double other_dir = robot.getDirection();
//            double dif = abs(dir - other_dir); // 角度差
//            // pi/2到pi*3/2之间
//            if (PI / 2 < dif && dif < PI * 3 / 2) {
//                robots[robotId].rotate(offset_angle);
//            }
//        }
//    }
//}

// 碰撞检测
// to do:有多个机器人在检测范围内 考虑最近的一个
void checkCollision(const int& robotId) {
    double offset_angle = PI / 1.1;
    double cur_dirction[2]{ cos(robots[robotId].getDirection()),sin(robots[robotId].getDirection()) };
    double cur_coor[2]{ robots[robotId].getCoordinateX(),robots[robotId].getCoordinateY() };

    for (auto& robot : robots) {
        double distance = robot.calDistance(robots[robotId]);
        //double ratio = distance > 5 ? 5 : distance;
        //double check_distance = RADUIS_FULL * 2.1 * ratio;
        //double check_angle = PI / 2 / ratio;
        //double check_angle = PI / 2 + 1.0 / 4 + 1 / (ratio - 5);
        //double check_angle = PI * 3 / 5 - ratio * PI / 10;
        double check_distance = 6;
        double check_angle = PI / 6;

        if (robot.getRobotId() != robotId) {
            double other_coor[2]{ robot.getCoordinateX(),robot.getCoordinateY() };
            // 计算当前机器人朝向和目标位置之间的叉乘
            double dx = other_coor[0] - cur_coor[0];
            double dy = other_coor[1] - cur_coor[1];
            double dir[2] { dx / sqrt(dx * dx + dy * dy) , dy / sqrt(dx * dx + dy * dy) };
            double cross = cur_dirction[0] * dir[1] - cur_dirction[1] * dir[0];

            // 计算当前机器人朝向和目标位置之间的夹角
            double cos = cur_dirction[0] * dir[0] + cur_dirction[1] * dir[1];
            if (cos < -1) {cos = -1;}
            if (cos > 1) {cos = 1;}
            double between_angle = acos(cos);

            // 计算角度差
            //double dif = abs(robots[robotId].getDirection() - robot.getDirection()); // 角度差
            double cur_angle = robots[robotId].getDirection() > 0 ? robots[robotId].getDirection() : robots[robotId].getDirection() + 2 * PI;
            double other_angle = robot.getDirection() > 0 ? robot.getDirection() : robot.getDirection() + 2 * PI;
            double dif = abs(cur_angle - other_angle); // 角度差
            
            // 只检测当前朝向一定范围内的扇形区域
            if (between_angle < check_angle && distance < check_distance ) {
                //// A×B为正 B在A的逆时针方向 否则顺时针方向 
                //if (cross > 0) {
                //    // 顺时针转
                //    robots[robotId].rotate(-offset_angle);
                //}
                //else {
                //    robots[robotId].rotate(offset_angle);
                //}
                if (PI / 2 / 1.1 <= dif && dif < PI) {
                    // 顺时针转
                    robots[robotId].rotate(-offset_angle);
                }
                else if (PI <= dif && dif <= PI * 3 / 2 * 1.1) {
                    // 逆时针转
                    robots[robotId].rotate(offset_angle);
                }
            }

            // 特殊情况下两个一直贴在一起
            if (distance < RADUIS_FULL * 2.1 && PI / 2 <= dif && dif < PI * 3/2) {
                robots[robotId].rotate(offset_angle);
            }
        }
    }
}

void action() {
    for (int robotId = 0; robotId < 4; robotId++) {
        int target_bench = robots[robotId].getTargetBenchId();
        //int curbenchId = robots[robotId].getWorkbenchId();
        // 目标一旦确定不会变
        if (target_bench == -1) {
            // 买入
            if (robots[robotId].getGoodsType() == 0) {
                int sell_bench, goods_type;
                int bench_7;

                // 7号一好就去买
                /*if ((bench_7 = judge_3()) >= 0) {
                    target_bench = bench_7;
                }*/

                // 若当前所在工作台产品格有产品 
                /*else if (curbenchId != -1 && workbenchs[curbenchId].getProductStatus() == 1) {
                    target_bench = curbenchId;
                }*/
                
                // 没有工作台7
                if (workbench_num_7 == 0) {
                    //target_bench = senior_first(robotId);
                    //target_bench = closest_first(robotId);
                    target_bench = unit_profit_first(robotId);
                }

                else if (judeg_5(robotId, bench_7)) {
                    target_bench = bench_7;
                }

                // 若7号工作台没有目标是它 且只缺一个材料 去买这个材料
                /*else if (judge_2(sell_bench, goods_type)) {
                    target_bench = findMaterial(robotId, goods_type, sell_bench);
                }*/

                // 若位于456工作台上 且该工作台缺一个材料 找这个材料带回来
                /*else if (( goods_type = judge_1(robotId) ) > 0) {
                    robots[robotId].setSellBenchId(workbenchs[curbenchId]);
                    target_bench = findMaterial(robotId, goods_type);
                }*/

                // 一个以上工作台7
                else if (workbench_num_7 > 1) {
                    //target_bench = findMaterial(robotId, 7);
                    target_bench = unit_profit_first(robotId);
                    //target_bench = closest_first(robotId);
                }

                // 一个工作台7
                else if (workbench_num_7 == 1) {
                    target_bench = unit_profit_first(robotId);
                    /*// 机器人0买4 机器人1买5 机器人2买6 机器人3买321循环
                    if (robotId == 0) {
                        target_bench = findMaterial(robotId, 4);
                    }
                    else if (robotId == 1) {
                        target_bench = findMaterial(robotId, 5);
                    }
                    else if (robotId == 2) {
                        target_bench = findMaterial(robotId, 6);
                    }
                    else if (robotId == 3) {
                        target_bench = findMaterial(robotId, robots[robotId].getCount());
                    }*/
                }
                // 剩余时间不足以买7并卖掉
                if (judge_4(robotId, target_bench)) {
                    //target_bench = closest_first(robotId);
                    target_bench = findMaterial(robotId, 1, 0);
                }
            }

            // 卖出
            else {
                // 回到买入时指定的工作台
                // 判断该工作台是否已经被作为其他机器人的目标
                if (robots[robotId].getSellBenchId() != -1 && !checkConflict(robotId, robots[robotId].getSellBenchId())) {
                    target_bench = robots[robotId].getSellBenchId();
                }
                // 去最近的卖
                else {
                    target_bench = findSellBench(robotId);
                }
            }
        }
        if (target_bench == -1) {
            cerr << "err:action" << endl;
        }
        
        robots[robotId].move(workbenchs[target_bench]);
        checkCollision(robotId);
    }
}

bool readMap() {
    char line[1024];
    int workbenchId = 0;
    int robotId = 0;
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'O' && line[1] == 'K') {
            workbench_num = workbenchs.size();
            return true;
        }
        for (int i = 0; i < 100; i++) {
            if (line[i] == 'A') {
                Robot r = Robot(robotId);
                ++robotId;
                robots.push_back(r);
            }
            else if (line[i] != '.') {
                Workbench wb = Workbench(workbenchId, line[i] - '0');
                ++workbenchId;
                workbenchs.push_back(wb);
            }
        }
    }
    return false;
}

bool readFrame() {
    char line[1024];
    int index = 0;
    int robotId = 0;
    int type = 0, restFrame = 0, materialStatus = 0, productStatus = 0;
    double w_coordinate[2]{ 0,0 };
    int workbenchId = 0, goodsType = 0;
    double timeCoefficient = 0, collisionCoefficient = 0, angleSpeed = 0, lineSpeed[2]{ 0,0 }, direction = 0, r_coordinate[2]{ 0,0 };
    fgets(line, sizeof line, stdin); // 吸收掉一个换行符
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'O' && line[1] == 'K') {
            return true;
        }
        std::stringstream ss(line);
        if (index < workbench_num) {
            ss >> type >> w_coordinate[0] >> w_coordinate[1] >> restFrame >> materialStatus >> productStatus;
            workbenchs[index].setType(type);
            workbenchs[index].setRestFrame(restFrame);
            workbenchs[index].setMaterialStatus(materialStatus);
            workbenchs[index].setProductStatus(productStatus);
            workbenchs[index].setCoordinateX(w_coordinate[0]);
            workbenchs[index].setCoordinateY(w_coordinate[1]);
        }
        else {
            ss >> workbenchId >> goodsType >> timeCoefficient >> collisionCoefficient >> angleSpeed >>
                lineSpeed[0] >> lineSpeed[1] >> direction >> r_coordinate[0] >> r_coordinate[1];
            robotId = index - workbench_num;
            robots[robotId].setWorkbenchId(workbenchId);
            robots[robotId].setGoodsType(goodsType);
            robots[robotId].setTimeCoefficient(timeCoefficient);
            robots[robotId].setCollisionCoefficient(collisionCoefficient);
            robots[robotId].setAngleSpeed(angleSpeed);
            robots[robotId].setLineSpeedX(lineSpeed[0]);
            robots[robotId].setLineSpeedY(lineSpeed[1]);
            robots[robotId].setDirection(direction);
            robots[robotId].setCoordinateX(r_coordinate[0]);
            robots[robotId].setCoordinateY(r_coordinate[1]);
        }
        ++index;
    }
    return false;
}

void classify() {
    Workbench* bench = nullptr;
    for (int i = 0; i < workbench_num; ++i) {
        switch (workbenchs[i].getType())
        {
        case 1:
            bench = &workbenchs[i];
            workbenchs_1.emplace_back(bench);
            break;
        case 2:
            bench = &workbenchs[i];
            workbenchs_2.emplace_back(bench);
            break;
        case 3:
            bench = &workbenchs[i];
            workbenchs_3.emplace_back(bench);
            break;
        case 4:
            bench = &workbenchs[i];
            workbenchs_4.emplace_back(bench);
            break;
        case 5:
            bench = &workbenchs[i];
            workbenchs_5.emplace_back(bench);
            break;
        case 6:
            bench = &workbenchs[i];
            workbenchs_6.emplace_back(bench);
            break;
        case 7:
            bench = &workbenchs[i];
            workbenchs_7.emplace_back(bench);
            break;
        case 8:
            bench = &workbenchs[i];
            workbenchs_8.emplace_back(bench);
            break;
        case 9:
            bench = &workbenchs[i];
            workbenchs_9.emplace_back(bench);
            break;
        default:
            break;
        }
    }
    workbench_num_1 = workbenchs_1.size();
    workbench_num_2 = workbenchs_2.size();
    workbench_num_3 = workbenchs_3.size();
    workbench_num_4 = workbenchs_4.size();
    workbench_num_5 = workbenchs_5.size();
    workbench_num_6 = workbenchs_6.size();
    workbench_num_7 = workbenchs_7.size();
    workbench_num_8 = workbenchs_8.size();
    workbench_num_9 = workbenchs_9.size();
}

int main() {
    // 初始化数据
    readMap();
    classify();
    puts("OK");
    fflush(stdout);
    //int frameId, money;
    int money;

    // 读取每帧输入信息
    while (scanf("%d %d", &frameId, &money) != EOF) {
        scanf("%d", &workbench_num);
        readFrame();

        // 输出控制指令
        printf("%d\n", frameId);

        action();
        //if (frameId > 50) action();
        printf("OK\n");
        fflush(stdout);
    }
    return 0;
}