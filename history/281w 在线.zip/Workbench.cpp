#include <iostream>
#include <math.h>
#include <unordered_map>
#include <string>
using namespace std;
class Workbench {
public:
	void print() const {
		std::cerr << "workbenchId: " << workbenchId << std::endl;
		std::cerr << "type: " << type << std::endl;
		std::cerr << "coordinate: (" << coordinate[0] << ", " << coordinate[1] << ")" << std::endl;
		std::cerr << "restFrame: " << restFrame << std::endl;
		std::cerr << "materialStatus: " << materialStatus << std::endl;
		std::cerr << "productStatus: " << productStatus << std::endl;
	}

	// ���������ĳ���
	inline double length(double dx, double dy) {
		return sqrt(dx * dx + dy * dy);
	}

	// ���㹤��̨�빤��̨֮��ľ���
	inline double calDistance(const Workbench& workbench) {
		double r_coor_x = this->getCoordinateX();
		double r_coor_y = this->getCoordinateY();
		double w_coor_x = workbench.getCoordinateX();
		double w_coor_y = workbench.getCoordinateY();
		double dx = w_coor_x - r_coor_x;
		double dy = w_coor_y - r_coor_y;
		double distance = length(dx, dy);
		return distance;
	}

private:
	int workbenchId;
	int type;
	double coordinate[2];
	int restFrame;
	int materialStatus;
	int productStatus;
	unordered_map <int, bool> reservedGoods;
public:
	Workbench(int _workbenchId, int _type) :workbenchId(_workbenchId), type(_type) {
		coordinate[0] = 0;
		coordinate[1] = 0;
		restFrame = -1;
		materialStatus = 0;
		productStatus = 0;
		reservedGoods = {
			{1,false},
			{2,false},
			{3,false},
			{4,false},
			{5,false},
			{6,false},
			{7,false},
			{8,false},
			{9,false}
		};
	};
	~Workbench(){};
	int getWorkbenchId() const { return workbenchId; }
	void setWorkbenchId(int id) { workbenchId = id; }
	int getType() const { return type; }
	void setType(int t) { type = t; }
	double getCoordinateX() const { return coordinate[0]; }
	void setCoordinateX(double x) { coordinate[0] = x; }
	double getCoordinateY() const { return coordinate[1]; }
	void setCoordinateY(double y) { coordinate[1] = y; }
	int getRestFrame() const { return restFrame; }
	void setRestFrame(int rt) { restFrame = rt; }
	int getMaterialStatus() const { return materialStatus; }
	void setMaterialStatus(int ms) { materialStatus = ms; }
	int getProductStatus() const { return productStatus; }
	void setProductStatus(int ps) { productStatus = ps; }
	bool getReservedGoods(int goods) { return reservedGoods[goods]; }
	void setReservedGoods(int goods, bool status) { reservedGoods[goods] = status; }
};
